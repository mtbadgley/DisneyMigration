blasting-data-functions
=======================

Regex functions to mask data
